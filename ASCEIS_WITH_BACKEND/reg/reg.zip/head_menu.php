 <ul class="nav navbar-nav">
            <li class="log_in"><a href="log_index.php">All registration</a></li>
             <li class="check_all_dd"><a href="show_dd_send.php">check reg by DD</a></li>   
			<li class="add_dd"><a href="add_dd.php">Add DD</a></li>    
			<li class="check_all"><a href="check_all.php">Check all DD</a></li>         
       		
          </ul>	
          <ul class="nav navbar-nav navbar-right">
          
            <li ><a href="logout.php">Log out</a></li>
          </ul>