<?php
		
		  include("../connection.php");
		$receipt_num=$_POST['receipt_num'];
		$dd_num=$_POST['dd_num'];
		$dd_amount=$_POST['dd_amount'];
		$paid_amount=$_POST['paid_amount'];
		$dd_branch=$_POST['dd_branch'];
		$dd_place=$_POST['dd_place'];
		$ices_cont=$_POST['ices_cont'];

				
		$acc_a=$_POST['acc_a'];
		
		$ices_cont=preg_replace("/[^0-9]/","",$ices_cont);	

		$receipt_num=stripslashes($receipt_num);
		$receipt_num = mysql_real_escape_string($receipt_num);

		$dd_num=stripslashes($dd_num);
		$dd_num = mysql_real_escape_string($dd_num);
		
		$dd_amount=stripslashes($dd_amount);
		$dd_amount = mysql_real_escape_string($dd_amount);
		
		$paid_amount=stripslashes($paid_amount);
		$paid_amount = mysql_real_escape_string($paid_amount);

		$dd_branch=stripslashes($dd_branch);
		$dd_branch = mysql_real_escape_string($dd_branch);
		
		$dd_place=stripslashes($dd_place);
		$dd_place = mysql_real_escape_string($dd_place);
		
		$ices_cont=stripslashes($ices_cont);
		$ices_cont = mysql_real_escape_string($ices_cont);
		
		
		$sql="INSERT INTO bank_dd values('null','$receipt_num','$dd_num','$dd_amount','$paid_amount','$dd_branch','$dd_place','$ices_cont','$acc_a')";
	
		$res=mysql_query($sql);
		if($res)
		{


		$eve_a=$_POST['eve_a'];
		$wor_a=$_POST['wor_a'];
		$exh_a=$_POST['exh_a'];
		$uce_a=$_POST['uce_a'];


		$eve_a=stripslashes($eve_a);
		$eve_a = mysql_real_escape_string($eve_a);

		$wor_a=stripslashes($wor_a);
		$wor_a = mysql_real_escape_string($wor_a);

		$exh_a=stripslashes($exh_a);
		$exh_a = mysql_real_escape_string($exh_a);

		$uce_a=stripslashes($uce_a);
		$uce_a = mysql_real_escape_string($uce_a);



		$eve_a=explode(",", $eve_a);
		$wor_a=explode(",", $wor_a);
		$exh_a=explode(",", $exh_a);
		$uce_a=explode(",", $uce_a);

		//events
	if($eve_a[0]!="555")
	{
		$i=0;

		while ($i<sizeof($eve_a)) {
			$sql="UPDATE eve_reg SET dd='t' WHERE u_id='".$ices_cont."' and id='".$eve_a[$i++]."'";
			$res=mysql_query($sql);
			if($res)
			{

			}
			else
			{
				echo mysql_error();
			}
		}
	}
	if($wor_a[0]!="555")
{
		$i=0;
		while ($i<sizeof($wor_a)) {
			$sql="UPDATE wor_reg SET dd='t' WHERE u_id='".$ices_cont."' and id='".$wor_a[$i++]."'";
			$res=mysql_query($sql);
			if($res)
			{
			}
			else
			{
				echo mysql_error();
			}
		}
}		

	if($exh_a[0]!="555")
	{
		$sql="UPDATE exh_reg SET dd='t' WHERE u_id='".$ices_cont."' and id='".$exh_a[0]."'";
	
			$res=mysql_query($sql);
			if($res)
			{
			}
			else
			{
				echo mysql_error();
			}
	}

	if($uce_a[0]!="555")
	{
		$sql="UPDATE uce_reg SET dd='t' WHERE u_id='".$ices_cont."' and id='".$uce_a[0]."'";
	
			$res=mysql_query($sql);
			if($res)
			{
			}
			else
			{
				echo mysql_error();
			}
	}

	header("location:success.php");
}
else
{
	echo mysql_error();
}
?>